# Line_bot_docomoAPI_image_recognition


Line bot with the docomo API (Image recognition) and recruit API (TalkAPI)


## Usage

You can add this chat bot on line.
When you send an image of products packages like snacks and processed foods
you would be able to get reply for product's information and webpages of Amazon.

When you send a messege bot chat would reply to you with a messege.


------------------------------------------------------------------------
